console.clear();
let arr = [2, 4, 6, 8]
let sum = 0

/* --------------------------------------- */
console.log("-----------------------------");
console.log("1. while");

let counter = 0;
while (counter <= 10) {
    console.log(counter);
    counter++;
}
console.log('while-loop ended');
console.log(counter);

let length = arr.length
counter = 0

while (arr.length) {
    sum = sum + arr.pop()
    console.log('intermediate result:', sum);
}
console.log('result:', sum);

// do {
//      var input = prompt('Please enter your name.')
// } while(!input || input.length === 0)

// console.log(input);

/* 1. The while loop */

/* --------------------------------------- */
console.log("-----------------------------");
console.log("2. for");

arr = [2, 4, 6, 8]
sum = 0

for (;arr.length; sum += arr.pop()) {
}
console.log('result for:', sum);

for (let n = 0; n <= 10; n++) {
    console.log('n:', n);
}

/* 2. The for loop */

/* --------------------------------------- */
console.log("-----------------------------");
console.log("3. for...in");

arr = [2, 4, 6]
for (let indx in arr) {
    console.log(indx, arr[indx]);
}

const obj = {name: "Sven", city: 'Berlin'}

for (let i in obj) {
    console.log(i, obj[i]);
}

/* 3. The for..in loop */

/* --------------------------------------- */
console.log("-----------------------------");
console.log("4. for...of");

arr = [2, 4, 6]
for (let element of arr) {
    console.log(element);
}

/* 4. The for..of loop */
